============
Installation
============

At the command line::

    $ pip install networking-midonet

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-midonet
    $ pip install networking-midonet
